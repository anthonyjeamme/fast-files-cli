import React from 'react'

const MyComponent = () => {
    return (<div className="MyComponent">MyComponent</div>
}

export default MyComponent
